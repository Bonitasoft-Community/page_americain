
Rem : version are saved in the properties files.

Todo : 
- Show the error in a better way
- show as an error that the Archive directory is not set (and when you drag and drop, tell it)
