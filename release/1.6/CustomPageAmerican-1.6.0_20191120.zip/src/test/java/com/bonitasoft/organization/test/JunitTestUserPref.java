package com.bonitasoft.organization.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class JunitTestUserPref {

	// @ T e s t
	public void simpleUserPref() {

		fail("Not yet implemented");
	}

}
